# -*- coding: utf-8 -*-

# rev 25 ����
# 27/04/2018

# import win32com.client
import zipfile, re, os, sys, time, datetime, uuid
import glob
import string


cnf=dict(zip([ 14,  17,  20,  22,  28,  29,  27,   9 ,  3 ,  2 , 15,  10,
                8 ,  4 , 23,  24,  26,   7 ,  6 ,  5 ,  1 , 16,  11,  18,  21 ],
             ['05','18','32','82','71','74','68','26','73','61','07','46',
              '56','21','48','51','65','44','53','59','63','12','14','23','35']))

shrtnm=dict(zip(['05','18','32','82','71','74','68','26','73','61','07','46',
                 '56','21','48','51','65','44','53','59','63','12','14','23','35'],
                ['vin','zht','kof','kmf','crk','crn','hmn','inf','crv','trn','vol','lvv',
                 'riv','uzh','nik','ods','hrs','lug','pol','sum','har','dnp','don','zap','kir']))



## BLOCK_US_2018_03_19_020047.csv 

## 2606000332529206;6;yyihi_3855@dsl.ukrtel.net;14.03.2018;30.01.2018;dsl_free_ day;260008;�����-���������� ���� ;����������;4;�� ��������������;���;
## 2606000332927365;8;bsilg_6930@dsl.ukrtel.net;14.03.2018;03.10.2017;dsl_pause;260008;�����-���������� ���� ;����������;4;�� ��������������;���;

## 630500|6305000044715200|dsl_free_2|5|xinbk_7580@dsl.ukrtel.net|1|2018-03-19 12:00:00|�� �������� � PG ord_2018-03-19_100_102112.txt||||
## 630700|6307000702292880|dsl_free_11_private|8|p491454@dsl.ukrtel.net|1|2018-03-19 12:00:00|�� �������� � PG ord_2018-03-19_100_102112.txt||||





if __name__ == '__main__':

 pattern = re.compile("^\d\d")

 z=datetime.datetime.now()

 dt_tm= '%d%2.2d%2.2d_%2.2d%2.2d' %(z.year,z.month,z.day,z.hour,z.minute)
 dt_tm2= '%d-%2.2d-%2.2d_%2.2d%2.2d' %(z.year,z.month,z.day,z.hour,z.minute)
 dt_ts= '%d-%2.2d-%2.2d %2.2d:%2.2d:%2.2d' %(z.year,z.month,z.day,z.hour,z.minute,z.second)

 print dt_tm2
 dt_blk=[]

 #for k in xrange(4):
 for k in xrange(1):
    DAY = datetime.timedelta(k)
    z=z-DAY
    dt_blk.append( '_%d_%2.2d_%2.2d_' %(z.year,z.month,z.day))
 #print dt_blk
 #exit()

 arof_FilesPP  ={}
 arof_FilesPP_ ={}

 for rr in shrtnm.keys():
      arof_FilesPP[rr]=open("777\\" + rr,"wt")

 am={}
 for fblk in dt_blk:
    for rnm in glob.glob("z:\\aup\\BLOCK_US\\BLOCK_US" + fblk +  "*.csv"):
    #for rnm in glob.glob("BLOCK_US" + fblk +  "*.csv"):
          for ln in open(rnm).readlines():
                if len(ln)>20 and pattern.findall(ln):
                    s=ln.rstrip().split(';')
                    #print s[0]
                    #am[s[2]]=s[6]
                    if s[0][:2] in shrtnm.keys():
                        print >> arof_FilesPP[s[0][:2]], "%s|%s|%s|%s|%s" % (s[6],s[0],s[5],s[1],s[2])
 for rr in shrtnm.keys():
      arof_FilesPP[rr].close()
 arof_FilesPP={}

 for rnm in glob.glob("ord_" + dt_tm2[:10] +  "*_swap*2.txt"):
      print rnm 
      fto=open(rnm[:-4] + "_" + rnm[-4:],"wt")
      for rr in shrtnm.keys():
          arof_FilesPP_[rr]=open("777\\" + "_" + rr  ,"wt")
      for ln in open(rnm).readlines():
             s=ln.rstrip().split('|')
             if s[1][:2] in shrtnm.keys():
                  print >> arof_FilesPP_[s[0][:2]], s[4]
      for rr in shrtnm.keys():
             arof_FilesPP_[rr].close()
      arof_FilesPP_={}

      for rr in shrtnm.keys():
            for pp in open("777\\_" + rr).xreadlines():
                    am[pp.strip()]="1"
            for pp in open("777\\" + rr).xreadlines():
                    smm= pp.rstrip()
                    s=smm.split('|')
                    if s[4] in am.keys():
                         print >> fto , "%s|1|%s 06:00:00|�� ������ �������������||||" % (smm, dt_tm2[:10])
      fto.close()


 exit()


  # |1|2018-04-26 15:00:00|�� ������ �������������||||
