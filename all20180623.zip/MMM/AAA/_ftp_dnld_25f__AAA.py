# -*- coding: utf-8 -*-

## -- ������� !!!   IN_OUT_t_ --> IN_OUT

## ------- ver. 14/07/2017 ���� ���� "_ftp_dnld_25f__.ini", ��� ���� ���������� ��� ��������
## ------- ver. 21/02/2017 �������� �� TOPAM='\\\\corp\\Kyiv\\SrvsResources\\MediationSystem\\FICS\\8134000011\\Contracts\\'
## ------- ver. 28/12/2016 ������� lvv riv uzh !!
## ------- ver. 03/11/2016 ������� ������ !!
## ------- ver. 22/06/2016 ������� �������� ��������� + ������ �� 10 ����� !!
## ------- ver. 24.05.2016 ������� 5 ��������� - �����
## ------- ver. 19.05.2016


#import win32com.client
#from datetime import datetime, timedelta
import zipfile, re, os, sys, time, datetime, uuid
import glob



if __name__ == '__main__':
   cnf={}
   cnf[14]='05'
   cnf[17]='18'
   cnf[20]='32'
   cnf[22]='82'
   cnf[28]='71'
   cnf[29]='74'

   cnf[27]='68'
   cnf[9] ='26'
   cnf[3] ='73'
   cnf[2] ='61'

   cnf[15]='07'
   cnf[10]='46'
   cnf[8] ='56'
   cnf[4] ='21'

### -----
   cnf[23]='48'
   cnf[24]='51'
   cnf[26]='65'

   cnf[7] ='44'
   cnf[6] ='53'
   cnf[5] ='59'
   cnf[1] ='63'

   cnf[16]='12'
   cnf[11]='14'
   cnf[18]='23'
   cnf[21]='35'




   
   shrtnm={}
   shrtnm[cnf[14]]='vin'
   shrtnm[cnf[17]]='zht'
   shrtnm[cnf[20]]='kof'
   shrtnm[cnf[22]]='kmf'
   shrtnm[cnf[28]]='crk'
   shrtnm[cnf[29]]='crn'

   shrtnm[cnf[27]]='hmn'
   shrtnm[cnf[9]] ='inf'
   shrtnm[cnf[3]] ='crv'
   shrtnm[cnf[2]] ='trn'

   shrtnm[cnf[15]]='vol'
   shrtnm[cnf[10]]='lvv'
   shrtnm[cnf[8]] ='riv'
   shrtnm[cnf[4]] ='uzh'

### -----
   shrtnm[cnf[23]]='nik'
   shrtnm[cnf[24]]='ods'
   shrtnm[cnf[26]]='hrs'

   shrtnm[cnf[7]] ='lug'
   shrtnm[cnf[6]] ='pol'
   shrtnm[cnf[5]] ='sum'
   shrtnm[cnf[1]] ='har'

   shrtnm[cnf[16]]='dnp'
   shrtnm[cnf[11]]='don'
   shrtnm[cnf[18]]='zap'
   shrtnm[cnf[21]]='kir'


   
   aa={}
   aa[cnf[14]]=[]
   aa[cnf[17]]=[]
   aa[cnf[20]]=[]
   aa[cnf[22]]=[]
   aa[cnf[28]]=[]
   aa[cnf[29]]=[]

   aa[cnf[27]]=[]
   aa[cnf[9]]=[]
   aa[cnf[3]]=[]
   aa[cnf[2]]=[]

   aa[cnf[15]]=[]
   aa[cnf[10]]=[]
   aa[cnf[8]]=[]
   aa[cnf[4]]=[]

### -----
   aa[cnf[23]]=[]
   aa[cnf[24]]=[]
   aa[cnf[26]]=[]
   
   aa[cnf[7]] =[]
   aa[cnf[6]] =[]
   aa[cnf[5]] =[]
   aa[cnf[1]] =[]

   aa[cnf[16]]=[]
   aa[cnf[11]]=[]
   aa[cnf[18]]=[]
   aa[cnf[21]]=[]



   #TOPAG='\\\\kv-kr-kof-s013\\kv-kr-kof-easkr\\docs\\EASKR_BANKS\\IN_OUT\\US_EASKR\\CONTRACTS_FROM_US\\'
   TOPAG="D:\\tmp\\MMM\\CONTRACTS_FROM_US\\"
   

   #TOORAG='\\\\corp\\Kyiv\\NFSResource\\EASKR\\'

   #TOPAM='\\\\corp\\Kyiv\\SrvsResources\\MediationSystem\\FICS\\8134000011\\Contracts\\'
   TOPAM='D:\\tmp\\MMM\\Contracts\\'
 
   #TOPAM='K:\\'

   #TOPAS='D:\\WORK\\scripts\\astra\Perl\\FTP_download\\13\\'
   TOPAS=TOPAG + 'ARHIV\\'

   sFnm_busy=TOPAG + "__busy_ftp_dnld.already"

   if os.access(sFnm_busy, os.F_OK):
      print "BUSY already ..."
      sys.exit()
   else:
      fbb=open(sFnm_busy,'wt')
      fbb.close()


   
   znow=datetime.datetime.now()
   #z=datetime.datetime.fromordinal(znow.toordinal()-1)

   ## �������� � ���-���� ����������� ���� ---------+
   ## mmdt  -> ���� �� ���-����� "_ftp_dnld_25f__.ini", 
   ##          � ������� ������ ������� �����

   sini="_ftp_dnld_25f__.ini"

   if os.path.exists(sini):
      fini=open(sini, "r+")
      smmdt= fini.readline()[:8]
      mmdt=datetime.datetime.strptime( smmdt, '%Y%m%d')
   else:
      fini=open(sini, "w")
      fini.write('{:4d}{:02d}{:02d}'.format(znow.year, znow.month, znow.day))
      print 'not exist file "_ftp_dnld_25f__.ini" --> makes it !!\n fill now previous date "yyyymmdd" \n in file "_ftp_dnld_25f__.ini"\n'
      exit(0)

   print ('%d%2.2d%2.2d' %(mmdt.year,mmdt.month,mmdt.day))

   fini.seek(0)
   fini.write('{:4d}{:02d}{:02d}'.format(znow.year, znow.month, znow.day))
   fini.close()
   ## ---------------------------------------------+

   ##  ���������� ���� !!!
   z=datetime.datetime.fromordinal(datetime.datetime.now().toordinal()-1)


   #print z, z.strftime("%d.%m.%Y %I:%M %p"),"-->" 
   #print '%d%2.2d%2.2d %2.2d%2.2d%2.2d-%d' %(z.year,z.month,z.day,z.hour,z.minute,z.second,z.microsecond)

   sday_yesterday='%d%2.2d%2.2d' %(z.year,z.month,z.day)

   lst_of_out_fls= []

   #mmdt= datetime.datetime.fromordinal(  datetime.datetime.strptime( smmdt, '%Y%m%d').toordinal()    +5 )
   #print '{:4d}{:02d}{:02d}'.format(mmdt.year,mmdt.month,mmdt.day)
   #mmdt=datetime.datetime.strptime( smmdt, '%Y%m%d') +3
   #print '{:4d}{:02d}{:02d}'.format(mmdt.year,mmdt.month,mmdt.day)

   while smmdt <= sday_yesterday:
         lst_of_out_fls.append(smmdt)
         mmdt= datetime.datetime.fromordinal(mmdt.toordinal() +1 )
         smmdt='{:4d}{:02d}{:02d}'.format(mmdt.year,mmdt.month,mmdt.day)
         #print smmdt

   print  len(lst_of_out_fls), lst_of_out_fls

   ## ����� ���� ������ �������

   if  len(lst_of_out_fls)==0:
        print "No files for loading ... for this date " + smmdt +' in file "_ftp_dnld_25f__.ini"'
        exit(0)

   ## ������ dict of our files : dourfls
   ## ������ list of fulnms of files : fnmsfto

   dourfls={}
   fnmsfto=[]

   for kk in cnf.keys():
      stm = TOPAG + shrtnm[cnf[kk]] + "\\dog_" + sday_yesterday + "_" + shrtnm[cnf[kk]] + "_all.OUT"
      fnmsfto.append(stm)
      dourfls[cnf[kk]]=open(stm  ,"wt")

   # print '%d%2.2d%2.2d %2.2d%2.2d%2.2d' %(a.year,a.month,a.day,a.hour,a.minute,a.second),

   spre="OONTRACTS_" + sday_yesterday
   # print  TOPAM + spre +'*.OUT'

   # ��������� 3 ��������� ���������� ����� ("*.OUT") � ���������� TOPAS (�����)
   # ��� 3*n ������ ���� ��������� ����� � ����������� � ��������� �������� � �������
   
   cnt_of_fls=0

   for srr in lst_of_out_fls:
         spre="OONTRACTS_" + srr
         for nmz in glob.glob(TOPAM + spre +'*.OUT'):
                if os.access(nmz, os.F_OK):
                    if os.stat(nmz).st_size<>0 :
                        # print TOPAS
                        os.system("copy /Y /Z " + nmz + " " + TOPAS)
                        cnt_of_fls=cnt_of_fls + 1
                        #print nmz  

   print cnt_of_fls

   if cnt_of_fls >= 1 :
       for srr in lst_of_out_fls:
           spre="OONTRACTS_" + srr
           for nmt in glob.glob(TOPAS + spre +'*.OUT'):
               cnt_of_lns=0
               print nmt,
               for line in open(nmt).readlines():
                  #print line[:-1]
                  mss =line.rstrip().split('|')
                  if mss[3] in ('DialupGuest','dsl_start','fttb_start','VoipGuest'):
                     continue
           
                  if mss[6] in ('1','2','5'):
           
                      #if(mss[6]=='5' and int(mss[9][0:4])-int(sday_yesterday[0:4])>1 ):
           
                      if(mss[6]=='5' and int(mss[8][0:4]+mss[8][5:7])-int(sday_yesterday[0:6])< -12  ):
                             # print mss
                             # print sday_yesterday, mss[8][0:4]+mss[8][5:7], sday_yesterday, int(mss[8][0:4]+mss[8][5:7])-int(sday_yesterday[0:6]),   mss[9]
                             continue
           
                      if(mss[6]=='5' and mss[9][0:12] in('�������� ���','�������� ���') ):
                             # print mss
                             # print sday_yesterday, mss[9][0:4], sday_yesterday, int(mss[9][0:4])-int(sday_yesterday[0:4]),   mss[9]
                             continue
           
                      if mss[2][0:2] in  cnf.values():
                             # print >>  dourfls[mss[2][0:2]]  ,line[:-1]
                             if(mss[9]==""): mss[9]="null"
                             #print >> dourfls[mss[2][0:2]] , '%s|%s|%s|%s|%s|%s|%s|%s 00:00:00|%s 00:00:00|%s|||%s 00:00:00|%s' % (mss[0],mss[1],mss[2],mss[4],mss[5],mss[3],mss[6],mss[8], mss[9],mss[14],mss[8],mss[10])

                             print >> dourfls[mss[2][0:2]] , '%s' % (line.rstrip())
                             cnt_of_lns = cnt_of_lns + 1 
               print " -->",cnt_of_lns


   # ������� ������� �����
   for key in  dourfls.keys() :
       dourfls[key].close()



   # �������� ������� ����� 

   try:
      import zlib
      compression = zipfile.ZIP_DEFLATED
   except:
      compression = zipfile.ZIP_STORED

   curdir_=os.getcwd()

   for sfnmf in fnmsfto:
       os.chdir(os.path.dirname(sfnmf))
       sdf=os.path.basename(sfnmf)
       zf=zipfile.ZipFile(sdf[:-3]+"zip",mode='w')
       zf.write(sdf,compress_type=compression)
       zf.close()
       os.remove(sdf)
   os.chdir(curdir_)

   print "---- sss----"


   # ���Ш� ����-������� "__busy_ftp_dnld.already"

   if  os.access(sFnm_busy, os.F_OK):
     os.remove(sFnm_busy)
