# -*- coding: utf-8 -*-

# 09/06/2017 - ������� try .. except
# 11/05/2017 - ������ ��� � BIN
# 18/04/2017 - ������� �������       xpon_ --> DSL 
# 22/02/2017 - ������� �������       vdsl_ --> DSL , ����� ��������� 08/11/2016
# 29/12/2016 - ������� lvv riv uzh
# 08/11/2016 - ������� �������������� vdsl --> dsl +
# 03/11/2016 - ������� ������
# 24/10/2016 - ���������� (������ + dop_fixedIP) --> DSL
# 30/09/2016 - ���������� ������� "
# 24/06/2016 - 10 ��������
# 23/05/2016 - ������� �������� �� �������� 5
# 18/04/2016

# import win32com.client
import zipfile, re, os, sys, time, datetime, uuid
import glob
import string


## 134136604^321013^3210130073018710^DialupGuest^0^380447352420^5^2004-12-08 00:00:00^2006-07-10 00:00:00^null^^^2005-08-11 02:47:05^2016-03-15 10:25:14
##      0      1        2                3       4     5        6       7                8                  9      12                   13





if __name__ == '__main__':

 #TOPAG='\\\\kv-kr-kof-s013\\kv-kr-kof-easkr\\docs\\EASKR_BANKS\\IN_OUT\\US_EASKR\\CONTRACTS_FROM_US\\' 
 TOPAG="D:\\tmp\\MMM\\CONTRACTS_FROM_US\\"

 TOORAG='\\\\corp\\Kyiv\\NFSResource\\EASKR\\'
 #TOORAG="D:\\tmp\\MMM\\EASKR\\"

 #F:\EASKR_BANKS\IN_OUT\US_EASKR\CONTRACTS_FROM_US\KV\
 
 sFnm_busy=TOPAG + "__busy.already"

 if os.access(sFnm_busy, os.F_OK):
    print "BUSY already ..."
    sys.exit()
 else:
    fbb=open(sFnm_busy,'wt')
    fbb.close()

 z=datetime.datetime.now()
 dt_tm= '%d%2.2d%2.2d_%2.2d%2.2d' %(z.year,z.month,z.day,z.hour,z.minute)

 cnf={}
 cnf[14]='05'
 cnf[17]='18'
 cnf[20]='32'
 cnf[22]='82'
 cnf[28]='71'
 cnf[29]='74'

 cnf[27]='68'
 cnf[9] ='26'
 cnf[3] ='73'
 cnf[2] ='61'

 cnf[15]='07'
 cnf[10]='46'
 cnf[8]= '56'
 cnf[4]= '21'

### -----
 cnf[23]='48'
 cnf[24]='51'
 cnf[26]='65'

 cnf[7] ='44'
 cnf[6] ='53'
 cnf[5] ='59'
 cnf[1] ='63'

 cnf[16]='12'
 cnf[11]='14'
 cnf[18]='23'
 cnf[21]='35'


 
 shrtnm={}
 shrtnm[cnf[14]]='vin'
 shrtnm[cnf[17]]='zht'
 shrtnm[cnf[20]]='kof'
 shrtnm[cnf[22]]='kmf'
 shrtnm[cnf[28]]='crk'
 shrtnm[cnf[29]]='crn'

 shrtnm[cnf[27]]='hmn'
 shrtnm[cnf[9]] ='inf'
 shrtnm[cnf[3]] ='crv'
 shrtnm[cnf[2]] ='trn'

 shrtnm[cnf[15]]='vol'
 shrtnm[cnf[10]]='lvv'
 shrtnm[cnf[8]] ='riv'
 shrtnm[cnf[4]] ='uzh'

### -----
 shrtnm[cnf[23]]='nik'
 shrtnm[cnf[24]]='ods'
 shrtnm[cnf[26]]='hrs'

 shrtnm[cnf[7]] ='lug'
 shrtnm[cnf[6]] ='pol'
 shrtnm[cnf[5]] ='sum'
 shrtnm[cnf[1]] ='har'

 shrtnm[cnf[16]]='dnp'
 shrtnm[cnf[11]]='don'
 shrtnm[cnf[18]]='zap'
 shrtnm[cnf[21]]='kir'


 
 aa={}
 aa[cnf[14]]=[]
 aa[cnf[17]]=[]
 aa[cnf[20]]=[]
 aa[cnf[22]]=[]
 aa[cnf[28]]=[]
 aa[cnf[29]]=[]

 aa[cnf[27]]=[]
 aa[cnf[9]]=[]
 aa[cnf[3]]=[]
 aa[cnf[2]]=[]

 aa[cnf[15]]=[]
 aa[cnf[10]]=[]
 aa[cnf[8]]=[]
 aa[cnf[4]]=[]

### -----
 aa[cnf[23]]=[]
 aa[cnf[24]]=[]
 aa[cnf[26]]=[]
   
 aa[cnf[7]] =[]
 aa[cnf[6]] =[]
 aa[cnf[5]] =[]
 aa[cnf[1]] =[]

 aa[cnf[16]]=[]
 aa[cnf[11]]=[]
 aa[cnf[18]]=[]
 aa[cnf[21]]=[]





 for key in shrtnm.keys():

       TOPA=TOPAG+shrtnm[key]
 
       for nmf in glob.glob(TOPA+'\\'+'*.zip'):
           print nmf
       #   print nmf[0:-5]+nmf[-4:]
       #   if os.access(nmf, os.F_OK):
       #        os.remove(nmf) if(os.stat(nmf).st_size==0) else os.rename(nmf, TOPA + nmf[0:-5]+nmf[-4:])
       
           zip=zipfile.ZipFile(nmf)
           zip.extractall(TOPA)
           zip.close()
           for nmt in glob.glob(TOPA+'\\'+'*.out'):
                 print nmt
                 # ������� � ������� ���������� - ����� � ������ ��� ����������� ������
                 fpre=open(nmt)
                 spre=fpre.readline().split('|')[1][0:2]
                 print spre
                 fpre.close()
                 # continue

                 fDSL=open((TOPAG + spre + '_dsl_' + dt_tm+'.txt'),'wt')
                 fDOP=open((TOPAG + spre + '_dop_' + dt_tm+'.txt'),'wt')
                 fVPN=open((TOPAG + spre + '_vpn_' + dt_tm+'.txt'),'wt')
                 fBIN=open((TOPAG + spre + '_bin_' + dt_tm+'.txt'),'wt')
                 fTVO=open((TOPAG + spre + '_tvo_' + dt_tm+'.txt'),'wt')
                 fSFT=open((TOPAG + spre + '_sft_' + dt_tm+'.txt'),'wt')
                 fWIF=open((TOPAG + spre + '_wif_' + dt_tm+'.txt'),'wt')
                 fMAIL=open((TOPAG + spre+ '_mdd_' + dt_tm+'.txt'),'wt')

                 for line in open(nmt).readlines():
                        #print line[:-1]
                        mss =line.rstrip().split('|')
                        if mss[3] in ('DialupGuest','dsl_start','fttb_start','VoipGuest'):
                           continue
      
                        if mss[6] in ('1','2','5'):

                            sss=string.replace(line[:-1],'"',' ')

                            if mss[1] in ('440001','440002','440003','440004','440005','440006','440011',
                                          '440012','440013','440015','440026','440027','440028','444000',
                                          '140000','140001','140006','140010','140011','140015','140018',
                                          '140022','140023','140024','140025','140026','140027','144800'):
                                 print >> fBIN, sss
                            elif mss[3][0:7] in ('dop_fix'):
                                 print >> fDSL, sss
                            elif mss[3][0:5] in ('udhcp','fttb_','vdsl_','xpon_'):
                                 print >> fDSL, sss
                            elif mss[3][0:4]=='dsl_':
                                 print >> fDSL, sss
                            elif mss[3][0:4] in('mail','dial','disk'):
                                 print >> fMAIL, sss
                            elif mss[3][0:4] in ('tv_o','kino'):
                                 print >> fTVO, sss
                            elif mss[3][0:4] in ('vpn_','obu_','L2vp'):
                                 print >> fVPN, sss
                            elif mss[3][0:4] in ('sns_','sip_','ota_','892_'):
                                 print >> fSFT, sss
                            elif mss[3][0:4] in ('Wi-F','wifi'):
                                 print >> fWIF, sss

                            else:
                                print >> fBIN, sss


                 fDSL.close()
                 fDOP.close()
                 fMAIL.close()
                 fVPN.close()
                 fTVO.close()
                 fSFT.close()
                 fWIF.close()
                 fBIN.close()

                 # ��������� �������������� ������ �� ������� Oracle
                 for nmz in glob.glob(TOPAG + spre +'*.txt'):
                        if os.access(nmz, os.F_OK):
                            if os.stat(nmz).st_size==0 :
                                 os.remove(nmz)
                            else :
                                try:
                                   nmzto=nmz.replace(TOPAG+spre, TOORAG + shrtnm[spre] + '\\rep\\1\\US_DOG\\input\\' + spre )
                                   print nmzto
                                   os.remove(nmzto) if os.access(nmzto, os.F_OK) else os.rename(nmz, nmzto)
                                except:
                                   nmzto=nmz.replace(TOPAG+spre, TOPAG +'ERROR\\' + spre )
                                   print nmzto
                                   os.remove(nmzto) if os.access(nmzto, os.F_OK) else os.rename(nmz, nmzto)
                 os.remove(nmt) 

           # ��������� zip � �������� �����
           nmto=nmf.replace('\\' + shrtnm[key] + '\\', '\\ARHIV\\' + shrtnm[spre] + '_')
           print nmto
           if os.access(nmto, os.F_OK):
                   os.rename(nmto, nmto + '.' + dt_tm)
           os.rename(nmf,nmto)
 
 if  os.access(sFnm_busy, os.F_OK):
     os.remove(sFnm_busy)
 
 