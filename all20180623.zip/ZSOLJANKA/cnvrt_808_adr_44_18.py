# -*- coding: utf-8 -*-

import re
#import win32com.client
import zipfile, re, os, sys, time, datetime
import dbf, glob
from aqwe_ import cr_templ_8xx, cr_templ_raz, cr_templ_class

#'NAME C(30); age N(3,0); birth D'

tabname="__aa_2"
mcp="cp1251"
#mcp="cp866"


cnf=dict(zip([ 14,  17,  20,  22,  28,  29,  27,   9 ,  3 ,  2 , 15,  10,
                8 ,  4 , 23,  24,  26,   7 ,  6 ,  5 ,  1 , 16,  11,  18,  21 ],
             ['05','18','32','82','71','74','68','26','73','61','07','46',
              '56','21','48','51','65','44','53','59','63','12','14','23','35']))

shrtnm=dict(zip(['05','18','32','82','71','74','68','26','73','61','07','46',
                 '56','21','48','51','65','44','53','59','63','12','14','23','35'],
                ['vin','zht','kof','kmf','crk','crn','hmn','inf','crv','trn','vol','lvv',
                 'riv','uzh','nik','ods','hrs','lug','pol','sum','har','dnp','don','zap','kir']))


#dbegin  ;   ��           ; ��� ;��; ���  ;�;���_�����;���_����
#20030101;3205080000021600;20518;60;606060;0;1;3205080000021600



#if len(sys.argv)<>2:
#  print "not file_name in cmd_line !!!"
#  exit()


confin_csv = glob.glob("8XX//" + "*.csv")

r=0
for fnm_inclass in  confin_csv:
   if r==0:
       fnbase= os.path.splitext(os.path.basename(fnm_inclass) )[0]
       print fnbase

       fp= {}
       for  ff in shrtnm.keys():
            fp[ff]=open ("8XX//I//" + shrtnm[ff]+ "_" +fnbase + ".csv", "wt")
       for ln in open(fnm_inclass,"rt").readlines():
            s=ln.strip().split(';')
            #print s
            if s[1][:2] in  shrtnm.keys():
                print >> fp[s[1][:2]], ln.strip()
       for  ff in shrtnm.keys():
           fp[ff].close()
           if os.stat(fp[ff].name).st_size==0 :
               #print fp[ff].name
               os.remove(fp[ff].name)

       aro=[]
       configfiles = glob.glob("8XX//I//"  + "*.csv")
       for fn in configfiles:
            #print fn[4:7]
            #if fn[4:7] in shrtnm.values():
               aro[:]=[]
               for ln in (open(fn,"rt").readlines()):
                  aro.append( [s.strip() for s in (ln.strip().split(';')) ] )
               tabname= os.path.splitext(fn)[0]
               table =cr_templ_8xx(tabname, mcp)
               table.open(dbf.READ_WRITE)
               for k in range(len(aro)):
                   table.append()
               pp=0
               for rec in table:
                  with rec:
                        #print aro[pp][1]
                        #None
                        #print rec[0], rec.vcode
                        #if pp==1:
                        #    rec[1]= 'zxcv'
                        #rec[1] = dp[pp]
                        #rec.ddate = dbf.Date(*dd[pp])
                        #rec.ddate = ddttm[pp]  
                        
                        rec.vcode=     "808"
                        rec.ddate=     datetime.datetime.strptime(aro[pp][0],'%Y%m%d')
                        #rec.vsacct=    aro[pp][3] + "-" + aro[pp][1][10:15]
                        #rec.vsacct= "%s-%d" % (aro[pp][3],int(aro[pp][1][8:15]))
                        rec.vsacct=    aro[pp][7]
                        rec.vtechcode= aro[pp][2]
                        rec.vzone=     aro[pp][3]
                        rec.vstreet=   aro[pp][4]
                        rec.vhouse=    aro[pp][5]
                        rec.vadddata=  aro[pp][6]
                        rec.norder=    "4"
                        rec.dend=      datetime.datetime.strptime("29991231",'%Y%m%d')
                  pp=pp+1
               os.remove(fn)
   r=r+1
exit()


#dbegin  ;   ��           ; ��� ;��; ���  ;�;���_����� 
#20030101;3205080000021600;20518;60;606060;0;1;


########################################################## end end end
###########################################################
##########################################################
###########################################################
##########################################################
###########################################################
##########################################################
###########################################################



fnbase= os.path.splitext(os.path.basename(sys.argv[1]) )[0]


fp= {}
for  ff in shrtnm.keys():
    fp[ff]=open ("FF//" + fnbase + "__"+ shrtnm[ff] +".csv", "wt")

for ln in (open(sys.argv[1],"rt").readlines()):
      s=ln.strip().split(';')
      #print  "02;"+ s + ">01.01.2018;��4"
      if s[0][:2] in  shrtnm.keys():
          #print  "02;"+ s + ">01.01.2018;��4"
          #print >> fp[s[0][:2]], "02;"+ s[0] + ">01.01.2018;��4;��"
          #print >> fp[s[0][:2]], "02;"+ s[0] + ">01.01.2018;��4;��"
          if s[1] in ('243'):
               print >> fp[s[0][:2]], "02;"+ s[0] + ">01.02.2018;���;BILL4EMEIL"
               #print >> fp[s[0][:2]], "-02;"+ s[0] + ";���;BILL4EMEIL"
          else :
               print >> fp[s[0][:2]], "02;"+ s[0] + ">01.02.2018;���;"
               #print >> fp[s[0][:2]], "-02;"+ s[0] + ";���;"

for  ff in shrtnm.keys():
    fp[ff].close()
    if os.stat(fp[ff].name).st_size==0 :
         #print fp[ff].name
         os.remove(fp[ff].name)


aro=[]
configfiles = glob.glob("FF//"+ fnbase[:-4] + "*.csv")
for fn in configfiles:
 aro[:]=[]
 #print os.path.splitext(fn)[0]
 for ln in (open(fn,"rt").readlines()):
    aro.append( [s.strip() for s in (ln.strip().split(';')) ] )
 tabname= os.path.splitext(fn)[0]
 table =cr_templ_class(tabname, mcp)

 table.open(dbf.READ_WRITE)

 for k in range(len(aro)):
     table.append()

 pp=0
 for rec in table:
    with rec:
       #None
       #print rec[0], rec.vcode
       #if pp==1:
       #    rec[1]= 'zxcv'
       rec[0] = aro[pp][0] 
       rec[1] = aro[pp][1]
       rec[2] = aro[pp][2].decode(mcp)
       rec[3] = aro[pp][3].decode(mcp)
 
       #rec.ddate = dbf.Date(*dd[pp])
       #rec.ddate = ddttm[pp]  
 
 
       #rec.vcode=     aro[pp][0]
       #rec.ddate=     datetime.datetime.strptime(aro[pp][1],'%Y%m%d')
    pp=pp+1




exit()





tabname= os.path.splitext(os.path.basename(sys.argv[1]) )[0]


aro=[]
for ln in (open(sys.argv[1],"rt").readlines()):
    aro.append( [s.strip() for s in (ln.strip().split(';')) ] )
table =cr_templ_class(tabname, mcp)

table.open(dbf.READ_WRITE)

for k in range(len(aro)):
     table.append()


pp=0
for rec in table:
   with rec:
      #None
      #print rec[0], rec.vcode
      #if pp==1:
      #    rec[1]= 'zxcv'
      rec[0] = aro[pp][0] 
      rec[1] = aro[pp][1]
      rec[2] = aro[pp][2].decode(mcp)
      #rec[3] = aro[pp][3]

      #rec.ddate = dbf.Date(*dd[pp])
      #rec.ddate = ddttm[pp]  


      #rec.vcode=     aro[pp][0]
      #rec.ddate=     datetime.datetime.strptime(aro[pp][1],'%Y%m%d')
   pp=pp+1

exit()

