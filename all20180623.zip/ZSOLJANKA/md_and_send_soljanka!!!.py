# -*- coding: utf-8 -*-

import re
#import win32com.client
import zipfile, re, os, sys, time, datetime, glob
import dbf


znow=datetime.datetime.now()
sday_now='%d%2.2d%2.2d' %(znow.year,znow.month,znow.day)


#print sday_now

#cnf={}
cnf=dict(zip([ 14,  17,  20,  22,  28,  29,  27,   9 ,  3 ,  2 , 15,  10,
                8 ,  4 , 23,  24,  26,   7 ,  6 ,  5 ,  1 , 16,  11,  18,  21 ],
             ['05','18','32','82','71','74','68','26','73','61','07','46',
              '56','21','48','51','65','44','53','59','63','12','14','23','35']))

shrtnm=dict(zip(['05','18','32','82','71','74','68','26','73','61','07','46',
                 '56','21','48','51','65','44','53','59','63','12','14','23','35'],
                ['vin','zht','kof','kmf','crk','crn','hmn','inf','crv','trn','vol','lvv',
                 'riv','uzh','nik','ods','hrs','lug','pol','sum','har','dnp','don','zap','kir']))

who=('63','59','53',)
MMwho={'����':'63','����':'59','����':'53'}


### �������� ������� ###############################

#rootp="d:\\tmp\\22\\"
rootp="z:\\"

#################################################


## ����������� �����, ���� ���-�� ����������  � /rep/1/zsoljanka/

for dd in shrtnm.values():
    for j in ("sms", "collection", "class", "8xx", "rzp"):
        for k in ("/i", "/d", "/e"):
            try:
                os.stat(rootp + dd + "/rep/1/zsoljanka/" + j  + k)
            except:
                os.makedirs(rootp + dd + "/rep/1/zsoljanka/" + j  + k)

##############################################################################


for r in ("sms\\i\\", "collection\\i\\"):
    for nmf in glob.glob( r +'*.csv'):
        hh=nmf.split('\\')

        #print hh[-1][:3]
        #print nmf
        #print rootp + hh[-1][:3]+"\\rep\\1\\zsoljanka\\" + nmf

        os.remove(nmf) if(os.stat(nmf).st_size==0) else os.rename(nmf, rootp + hh[-1][:3]+"\\rep\\1\\zsoljanka\\" + nmf)

for r in ("class\\i\\", "8xx\\i\\", "rzp\\i\\"):
    for nmf in glob.glob( r +'*.dbf'):
        hh=nmf.split('\\')
        #print hh[-1][:3]
        #print nmf
        #print rootp + hh[-1][:3]+"\\rep\\1\\zsoljanka\\" + nmf
        os.remove(nmf) if(os.stat(nmf).st_size==0) else os.rename(nmf, rootp + hh[-1][:3]+"\\rep\\1\\zsoljanka\\" + nmf)

exit()

# os.remove(nmf) if(os.stat(nmf).st_size==0) else os.rename(nmf, TOPA + nmf[0:-5]+nmf[-4:])
