# -*- coding: utf-8 -*-

import re
#import win32com.client
import zipfile, re, os, sys, time, datetime
import dbf

#TOORAG='\\\\corp\\Kyiv\\NFSResource\\EASKR\\'

TOORAG="11\\"

f=open("---0.txt","w")
sys.stdout = f

znow=datetime.datetime.now()
sday_now='%d%2.2d%2.2d' %(znow.year,znow.month,znow.day)

#cnf={}
cnf=dict(zip([ 14,  17,  20,  22,  28,  29,  27,   9 ,  3 ,  2 , 15,  10,
                8 ,  4 , 23,  24,  26,   7 ,  6 ,  5 ,  1 , 16,  11,  18,  21 ],
             ['05','18','32','82','71','74','68','26','73','61','07','46',
              '56','21','48','51','65','44','53','59','63','12','14','23','35']))

shrtnm=dict(zip(['05','18','32','82','71','74','68','26','73','61','07','46',
                 '56','21','48','51','65','44','53','59','63','12','14','23','35'],
                ['vin','zht','kof','kmf','crk','crn','hmn','inf','crv','trn','vol','lvv',
                 'riv','uzh','nik','ods','hrs','lug','pol','sum','har','dnp','don','zap','kir']))


print cnf
print "======"
print shrtnm

dourfls={}                                                                                       
fnmsfto=[]                                                                                       
                                                                                                 
for kk in cnf.keys():                                                                            
   stm = TOORAG + "\\nar_" + sday_now + "_" + cnf[kk] + "_" + shrtnm[cnf[kk]] + "_.csv"
   fnmsfto.append(stm)                                                                           
   dourfls[cnf[kk]]=open(stm  ,"wt")                                                             


#fto=open("_0.txt", "wt")

pattern = re.compile("\(\d+\)")
m=pattern.findall("--�.������ (50) asdf")
print m

repl=""
for ln in  open("162_re.txt").readlines():
       ec=ln.split("\t")
       #repl=re.sub(pattern,pattern,ec[1])
       #print "%s;%s;%s" % (ec[0],ec[2],ec[1])
       st=ec[9]
       ec[9]=st[6:10]+st[3:5]+st[:2]
       ec[13]=ec[13][:2]
       if (ec[13]=="��" or ec[13]=="��") and ec[4][:1]=='�':
          for k in (14,10,1,3,6,11):
             #st="{};".format(ec[k-1])
             dourfls[ec[0][:2]].write(str(ec[k-1])+";")
             None
          dourfls[ec[0][:2]].write("\n")
          f.write("%s;%s;%s;%s;%s\n" % ("51" if ec[13]=="��" else " 1", ec[2],ec[9],ec[5],ec[10]))



table = dbf.Table('temptable', 'name C(30); age N(3,0); birth D',codepage='cp1251')
table.open()

for datum in (
                ('����������'.decode('cp1251'), 31, dbf.Date(1979, 9,13)),
                ('Ethan Furman', 102, dbf.Date(1909, 4, 30)),
                ('Jane Smith', 57, dbf.Date(1954, 7, 2)),
                ('John Adams', 44, dbf.Date(1967, 1, 9)),
                ):
   table.append(datum)
table.close()

t2=dbf.Table(
"mmm_raz", 
'D_DATE D; D_ACCOUNT C(16); D_PHONE C(50); D_TIME C(8); D_WORD C(6); D_COST N(12,2); D_OPER N(6,0); D_KR N(2,0); D_ACT N(3,0); D_ACT_DATE D; D_SALDO C(2)',  
codepage='cp1251')
