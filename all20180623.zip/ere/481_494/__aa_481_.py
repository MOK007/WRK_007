# -*- coding: utf-8 -*-

import re
#import win32com.client
import zipfile, re, os, sys, time, datetime
import dbf

#TOORAG='\\\\corp\\Kyiv\\NFSResource\\EASKR\\'

TOORAG="11\\"


znow=datetime.datetime.now()
sday_now='%d%2.2d%2.2d' %(znow.year,znow.month,znow.day)

#cnf={}
cnf=dict(zip([ 14,  17,  20,  22,  28,  29,  27,   9 ,  3 ,  2 , 15,  10,
                8 ,  4 , 23,  24,  26,   7 ,  6 ,  5 ,  1 , 16,  11,  18,  21 ],
             ['05','18','32','82','71','74','68','26','73','61','07','46',
              '56','21','48','51','65','44','53','59','63','12','14','23','35']))

shrtnm=dict(zip(['05','18','32','82','71','74','68','26','73','61','07','46',
                 '56','21','48','51','65','44','53','59','63','12','14','23','35'],
                ['vin','zht','kof','kmf','crk','crn','hmn','inf','crv','trn','vol','lvv',
                 'riv','uzh','nik','ods','hrs','lug','pol','sum','har','dnp','don','zap','kir']))


print cnf
print "======"
print shrtnm

dourfls={}                                                                                       
fnmsfto=[]                                                                                       
                                                                                                 
for kk in cnf.keys():                                                                            
   stm = TOORAG + "\\nar_" + sday_now + "_" + cnf[kk] + "_" + shrtnm[cnf[kk]] + "_.csv"
   fnmsfto.append(stm)                                                                           
   #dourfls[cnf[kk]]=open(stm  ,"wt")                                                             


fto=open("_0.txt", "wt")
fto2=open("t_zzzz.csv","wt")

pattern = re.compile("\(\d+\)")
m=pattern.findall("--�.������ (50) asdf")
#print m[0]
#exit()


BB=True
mrk="23" ; fnmfr="481_230000_.txt"

repl=""
#--481_820000_Report_WorkDslPortsOld_23052017005908.txt
for ln in  open(fnmfr).readlines():
       ec=ln.split("|")
       #repl=re.sub(pattern,pattern,ec[1])
       #print "%s;%s;%s" % (ec[0],ec[2],ec[1])
       ec[15]=ec[15][:1]
       if ec[5][:3]=="380":
           ec[5]=ec[5][:12]
       else :
           ec[5]="------------"
       try:
          st=pattern.findall(ec[16])[0]
          ec[16]=st
       except:
          ec[16]="--"
       #ec[16]=st[0]
       if ( ec[3]=="�����" and ec[4]=="��������" and ec[11]=="ADSL" and ec[15][:1]=="�" and
            (BB or len(ec[6])<>16 or ec[6][:2]<>mrk or ec[6].endswith(" "))  ):
          for k in (15,16,7,6,17,11,10,11,12,19,1):
             #st="{};".format(ec[k-1])
             fto.write(str(ec[k-1])+";")
             None
          #fto.write(str(st[0]))
          fto.write("\n")
          fto2.write("{};{};{}\n".format(ec[14],ec[16][1:3],ec[0]))



table = dbf.Table('temptable', 'name C(30); age N(3,0); birth D', codepage='cp1251')
table.open()
for datum in (
                ('John ������'.decode("cp1251"), 31, dbf.Date(1979, 9,13)),
                ('Ethan ������'.decode("cp1251"), 102, dbf.Date(1909, 4, 1)),
                ('Jane Smith', 57, dbf.Date(1954, 7, 2)),
                ('John Adams', 44, dbf.Date(1967, 1, 9)),
                ):
  table.append(datum)
table.close()