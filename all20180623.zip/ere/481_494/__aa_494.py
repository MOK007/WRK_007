# -*- coding: utf-8 -*-

import re
#import win32com.client
import zipfile, re, os, sys, time, datetime


#TOORAG='\\\\corp\\Kyiv\\NFSResource\\EASKR\\'

TOORAG="11\\"


znow=datetime.datetime.now()
sday_now='%d%2.2d%2.2d' %(znow.year,znow.month,znow.day)

#cnf={}
cnf=dict(zip([ 14,  17,  20,  22,  28,  29,  27,   9 ,  3 ,  2 , 15,  10,
                8 ,  4 , 23,  24,  26,   7 ,  6 ,  5 ,  1 , 16,  11,  18,  21 ],
             ['05','18','32','82','71','74','68','26','73','61','07','46',
              '56','21','48','51','65','44','53','59','63','12','14','23','35']))

shrtnm=dict(zip(['05','18','32','82','71','74','68','26','73','61','07','46',
                 '56','21','48','51','65','44','53','59','63','12','14','23','35'],
                ['vin','zht','kof','kmf','crk','crn','hmn','inf','crv','trn','vol','lvv',
                 'riv','uzh','nik','ods','hrs','lug','pol','sum','har','dnp','don','zap','kir']))


print cnf
print "======"
print shrtnm

dourfls={}                                                                                       
fnmsfto=[]                                                                                       
zones={}


for ln in open ("_zones.txt","rt").readlines():
    ec=ln.split(";")
    zones[ec[5]]=ec[3]
                                                                                                 
for kk in cnf.keys():                                                                            
   stm = TOORAG + "\\nar_" + sday_now + "_" + cnf[kk] + "_" + shrtnm[cnf[kk]] + "_.csv"
   fnmsfto.append(stm)                                                                           
   dourfls[cnf[kk]]=open(stm  ,"wt")                                                             


#fto=open("_0.txt", "wt")

pattern = re.compile("\(\d+\)")
m=pattern.findall("--�.������ (50) asdf")
print m

repl=""
for ln in  open("494_re_.txt").readlines():
       ec=ln.split("\t")
       #repl=re.sub(pattern,pattern,ec[1])
       #print "%s;%s;%s" % (ec[0],ec[2],ec[1])
       st=ec[11]
       ec[11]=st[6:10]+st[3:5]+st[:2]
       ec[16]=ec[16][:2]
       ## if ec[16]=="��" and ec[4][0]=='�' and sday_now > ec[11] :
       if ec[4][0]=='�' and sday_now > ec[11] :

          for k in (17,12,1,3,7,13):
             #st="{};".format(ec[k-1])
             dourfls[ec[0][:2]].write(str(ec[k-1])+";")
             None

          try:
            if ec[0][:2]=='82':
               st="00"
            else:
               st=zones[ec[0]]
          except:
            st="^^^"
          dourfls[ec[0][:2]].write(st+"\n")

