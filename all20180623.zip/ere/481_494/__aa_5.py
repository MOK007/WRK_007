# -*- coding: utf-8 -*-

import re
#import win32com.client
import zipfile, re, os, sys, time, datetime
import dbf
from aqwe_ import cr_templ_8xx, cr_templ_raz, cr_templ_class

#'NAME C(30); age N(3,0); birth D'

tabname="__aa_2"
mcp="cp1251"

tabname2="__aa_22"
mcp2="cp1251"



mmdt= datetime.datetime.strptime('2017-09-12','%Y-%m-%d')
mmdt= datetime.datetime.strptime('13092017','%d%m%Y')

#print mmdt
print datetime.datetime.now()


#print sys.argv[1]
if len(sys.argv)<>2:
  print "not file_name in cmd_line !!!"
  exit()

#os.path.splitext(os.path.basename(f))
tabname= os.path.splitext(os.path.basename(sys.argv[1]) )[0]

#804;20131101;3211140000000240;13014;74;;400;36;;1;4;29991231


aro=[]
for ln in (open(sys.argv[1],"rt").readlines()):
    aro.append( [s.strip() for s in (ln.strip().split(';')) ] )


#print aro

#print fields
#print fiel
#print "".join(fiel)
#table = dbf.Table('__aa_2',"".join(fiel()), codepage=mcp)

table =cr_templ_8xx(tabname, mcp)
table2=cr_templ_class(tabname2, mcp2)



#table = dbf.Table('__aa_2')
table.open(dbf.READ_WRITE)

dp=('olga','oleg')
dd=((2017,7,9),(2013,12,12))
ddttm=(datetime.datetime.strptime('13/09/2017','%d/%m/%Y'), datetime.datetime.strptime('12/05/1956','%d/%m/%Y'))

print len(aro)
for k in range(len(aro)):
     table.append()

#table.append(('pp','nn'))
#table.append(('zc','ww'))



#804;20131101;3211140000000240;13014;74;;400;36;;1;4;29991231

# vcode, ddate, vsacct, vtechcode, vzone, vpatr, 
# vwservtcon, vadddata, voper, ncpct, norder, dend

# 804; 20131101; 3211140000000240; 13014; 74; ;
# 400; 36; ; 1; 4; 29991231

pp=0
for rec in table:
   with rec:
      #None
      #print rec[0], rec.vcode
      #if pp==1:
      #    rec[1]= 'zxcv'
      #rec[1] = dp[pp]
      #rec.ddate = dbf.Date(*dd[pp])
      #rec.ddate = ddttm[pp]  


      rec.vcode=     aro[pp][0]
      rec.ddate=     datetime.datetime.strptime(aro[pp][1],'%Y%m%d')
      rec.vsacct=    aro[pp][2]
      rec.vtechcode= aro[pp][3]
      rec.vzone=     aro[pp][4]
      rec.vpatr=     aro[pp][5]
      rec.vwservtcon=aro[pp][6]
      rec.vadddata=  aro[pp][7]
      rec.voper=     aro[pp][8]
      rec.ncpct=     aro[pp][9]
      rec.norder=    aro[pp][10]
      rec.dend=      datetime.datetime.strptime(aro[pp][11],'%Y%m%d')
   pp=pp+1

exit()





for record in table:
  new_data={}
  new_data['vservtype']='aaa'
  new_data['vcode']='bbb'
  with record:
     None
     #dbf.write(record,('aaa','bbb'))





pp=0
with dbf.Table("__aa_2.dbf") as table:
    for record in dbf.Process(table):
        #if pp==0:  record[2] = dbf.Date(2017,7,9)
        #record[1] =dp[pp]
        pp=pp+1

exit()


#table.write_record(['hjk','rty'])

#print table[1][1]
#rec=[table.current()]
#print [table.current()]
#print rec['VCODE']
#rec['VCODE']="asdf"
#rec.ddate=dbf.Date(2017,7,9)


table.close()
table.open('__aa_2', 'rw')
table[1].delete_record()
table.close()




'''
table = dbf.Table('__aa_2', 'NAME C(30); age N(3,0); birth D', codepage='cp1251')
table.open()
for datum in (
                ("John ���'���".decode("cp1251"), 31, dbf.Date(1979, 9,13)),
                ('Ethan ������'.decode("cp1251"), 102, dbf.Date(1909, 4, 1)),
                ('Jane Smith', 57, dbf.Date(1954, 7, 2)),
                ('John Adams', 44, dbf.Date(1967, 1, 9)),
                ):
  table.append(datum)
table.close()

# ������� ������� ������������ ���������
$dbh->do("CREATE TABLE $table (
 VSERVTYPE       CHAR(5)
,VCODE           CHAR(5)
,DDATE           DATE
,VSACCT          CHAR(16)
,VTECHCODE       CHAR(30)
,VTECHTYPE       CHAR(10)
,VZONE           CHAR(10)
,VSUBSTYPE       CHAR(5)
,VSURNAME        CHAR(100)
,VNAME           CHAR(100)
,VPATR           CHAR(30)
,VSTREET         CHAR(10)
,VHOUSE          CHAR(10)
,VLETTER         CHAR(5)
,VFLAT           CHAR(10)
,VPRIVTYPE       CHAR(10)
,VWSERVT         CHAR(5)
,VPREVSERVT      CHAR(5)
,VWSERVTCON      CHAR(5)
,DPAYM           DATE
,NSUMONE         NUMERIC(10,2)
,VADDDATA        CHAR(250)
,VSECRET         CHAR(1)
,VOPER           CHAR(5)
,DWRITE          DATE
,VMFO            CHAR(10)
,VBANKACCT       CHAR(20)
,VOKPO           CHAR(10)
,VTAXCODE        CHAR(20)
,VCODEREGND      CHAR(20)
,VPOSTDEPT       CHAR(10)
,VATC            CHAR(10)
,NCPCT           NUMERIC(12,4)
,NORDER          NUMERIC(10,0)
,VDISTR          CHAR(5)
,DEND            DATE
,VSTREETK        CHAR(10)
,VHOUSEK         CHAR(10)
,VFLATK          CHAR(10))");

table = dbf.Table(tabname,  
'VSERVTYPE       C(5)
;VCODE           C(5)
;DDATE           D
;VSACCT          C(16)
;VTECHCODE       C(30)
;VTECHTYPE       C(10)
;VZONE           C(10)
;VSUBSTYPE       C(5)
;VSURNAME        C(100)
;VNAME           C(100)
;VPATR           C(30)
;VSTREET         C(10)
;VHOUSE          C(10)
;VLETTER         C(5)
;VFLAT           C(10)
;VPRIVTYPE       C(10)
;VWSERVT         C(5)
;VPREVSERVT      C(5)
;VWSERVTCON      C(5)
;DPAYM           D
;NSUMONE         N(10,2)
;VADDDATA        C(250)
;VSECRET         C(1)
;VOPER           C(5)
;DWRITE          D
;VMFO            C(10)
;VBANKACCT       C(20)
;VOKPO           C(10)
;VTAXCODE        C(20)
;VCODEREGND      C(20)
;VPOSTDEPT       C(10)
;VATC            C(10)
;NCPCT           N(12,4)
;NORDER          N(10,0)
;VDISTR          C(5)
;DEND            D
;VSTREETK        C(10)
;VHOUSEK         C(10)
;VFLATK          C(10)'
,codepage=mcp)



table.open()
table.close()

'''