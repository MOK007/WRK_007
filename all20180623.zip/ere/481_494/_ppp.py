# -*- coding: utf-8 -*-

import re
#import win32com.client
import zipfile, re, os, sys, time, datetime
import dbf

with open("481_630000_Report_WorkDslPortsOld_26092017222906.txt","rt") as f:
   for l in f.xreadlines():
        s=l.rstrip().split('|')
        if s[14]=="631100" and s[3]=="�����":
           print s[6]
           #print l.rstrip()