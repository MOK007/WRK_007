# -*- coding: utf-8 -*-

## ��������� "������" �����, ��������� � ������,���� � ���� � ����� \\kof\\m\\2\\
## � �����  "D:\\tmp\\mrak\\22\\"

#import win32com.client
#from datetime import datetime, timedelta
import zipfile, re, os, sys, time, datetime, uuid
import glob

if __name__ == '__main__':

   TOPAM= "\\\\corp\\Kyiv\\NFSResource\\EASKR\\kof\\m\\2\\"
   #TOPAM= "D:\\tmp\\mrak\\"

   TOPAS= "D:\\tmp\\mrak\\22\\"

   lst_of_out_fls_pre= ['cli_','ord_','adr_',]
   cnt_of_fls= 0

   znow=datetime.datetime.now()
   sznow='%d%2.2d%2.2d' %(znow.year,znow.month,znow.day)
   print sznow

   for srr in lst_of_out_fls_pre:
         for nmz in glob.glob(TOPAM + srr +'*.txt'):
                if os.access(nmz, os.F_OK):
                    sbsnmf= os.path.basename(nmz)
                    if os.stat(nmz).st_size<>0 :
                        if sbsnmf[4:12]<sznow and sbsnmf[13:15] < '21':
                             print sbsnmf, sbsnmf[4:12], sbsnmf[13:15]
                             os.system("move /Y " + nmz + " " + TOPAS + sbsnmf)
                             #os.system("copy /Y /Z " + nmz + " " + TOPAS)
                             cnt_of_fls=cnt_of_fls + 1

                        # print TOPAS
                        #print sbsnmf[13:15],nmz
                        #print os.path.basename(nmz)
                          
