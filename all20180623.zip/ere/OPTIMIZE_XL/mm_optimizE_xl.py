# -*- coding: utf-8 -*-
# ver. 18/07/2017 +++++


import sys, os, shutil
import re
import glob
import fnmatch
import cPickle as pickle
from datetime import datetime ,date, time, timedelta
import zipfile
from time import sleep

lstofcent=('05','18','32','71','74','82','26','61','68','73',
           '07','46','56','21','48','51','65','44','53','59','63','12','14','23','35')

#  --- nik ods hrs ---
# ,'48','51','65' 

#  --- lug pol sum har ---
# ,'44','53','59','63' 

#  --- dnp don zap kir ---
# ,'12','14','23','35' 



fnmsfto=[]


TFR='\\\\corp\\Kyiv\\NFSResource\\EASKR\\'

#TOPAG='\\\\kv-kr-kof-s013\\kv-kr-kof-easkr\\docs\\EASKR_BANKS\\IN_OUT\\US_EASKR\\777\\111\\' 
TOPAG='\\\\corp.ukrtelecom.loc\\Kyiv\\KyivMisto\\Common\\Rozr_group\\IN_OUT\\US_EASKR\\777\\111\\'



### ---------------- ����� �� ������� !!



#sleep(10)

#exit(0)


## -- ������� ��������� (���� ����� --> dq tq)
dt=datetime.now()
tt=dt.timetuple()
dq='{:4d}{:02d}{:02d}'.format(tt[0],tt[1],tt[2])
## |2|2016-08-03 00:00:00|||||
dq_ord='|2|{:4d}-{:02d}-{:02d} 00:00:00|||||'.format(tt[0],tt[1],tt[2])
tq='{:02d}{:02d}'.format(tt[3],tt[4])

tdtminus=(dt-timedelta(days= 5)).timetuple()

dtmdlt='{:4d}{:02d}{:02d}'.format(tdtminus[0],tdtminus[1],tdtminus[2])


print dtmdlt, dq, tq, dq_ord

print dt.isoweekday()
print tq[:2]
#print date(2017,3,19).isoweekday()

#---------------------
# ������� "������ ��� �������"

#BATTLE=True
BATTLE=False

#---------------------

if BATTLE:
    with open(TFR + 'kof\\m\\2\\in_pc.txt','wt') as sTpc:
      print >> sTpc,"0;"
    
    with open(TFR + 'kof\\m\\2\\_staRt','wt') as sTf:
      if dt.isoweekday()==6 :
         if tq[:2]=="19":
            print >> sTf,1
            exit(0)
         else:
            print >> sTf,0
            exit(0)
      elif dt.isoweekday()==7 :
         print >> sTf,0
         exit(0)
      else:
        if tq[:2] >= '07' and tq[:2] < '17' :
            print >> sTf,1  
            os.system("move /Y " + TFR + "kof\\m\\2\\*_ieh.txt")
            sleep(10)
        elif tq[:2] == '17':
            print >> sTf,1
            exit(0)
        elif tq[:2] >= '19':
            print >> sTf,0
            exit(0)
else:
   os.system("move /Y " + TFR + "kof\\m\\2\\*_ieh.txt")


#exit(0)

chr=""


#path="."

aapc={}


try:
    fh=open('opti.pkl','rb')
    aapc=pickle.load(fh)
    fh.close()
except:
    pass

p=re.compile('^[0-9]{16,16}\|',re.IGNORECASE)
pto=re.compile('\|[0-9]{16,16}\|',re.IGNORECASE)
#inpfs=(open(sys.argv[1])).readlines()

curdir_=os.getcwd()
#print curdir_

#--===== orders !!!! ----------------------------

#aapc={}
aanew={}
aanewlsofkeys=[]

ord_ou=[]

configfiles = glob.glob("ord*ieh.txt")
#configfiles.extend(glob.glob("ord*enr.txt"))
#configfiles.extend(glob.glob("ord*lvv.txt"))

for s in configfiles: print s

fnmsfto.extend(configfiles)

#exit(0)


for fnc in configfiles:
   for ln in  open(fnc).readlines():
       if ln[:2] in lstofcent and len(ln)==77:
          if '|' in (ln[23], ln[49] ) :
              mms= ln[7:23]+' '+ln[37:49]
              aanew[mms]=ln[:6]
              #print mms,aanew[mms]

aanewlsofkeys=list(set(aanew.keys())-set(aapc.keys()))

nmz='ord_'+dq+'_'+tq+'---.txt'
f_ordou=open( nmz,'wt')
for kk in  sorted(aanewlsofkeys):
    print >> f_ordou, "{}|{}|DialupGuest||{}{}".format(aanew[kk], kk[:16], kk[17:], dq_ord)
    aapc[kk]=dq
f_ordou.flush()
f_ordou.close()


aapc2={}
for key in sorted(aapc.keys(),key=lambda x: x[:16]):
    if  aapc[key] >= dtmdlt:
        aapc2[key]=aapc[key]
        #print key, aapc2[key]
    #print key, aapc[key]

with open ('opti.pkl','wb') as fh:
    pickle.dump(aapc2,fh)
    fh.close()


#exit(0)


#print nmz
if os.stat(nmz).st_size<>0 :
    os.system("copy /Y " + nmz + " " + TOPAG)
    fnmsfto.append(nmz)
else:
    os.remove(nmz)



#--===== clients !!!! ----------------------------

ord_ou[:]=[]
aapc.clear()

configfiles = glob.glob("cli*ieh.txt")
#configfiles.extend(glob.glob("cli*enr.txt"))
#configfiles.extend(glob.glob("cli*lvv.txt"))

#for s in configfiles: print s
fnmsfto.extend(configfiles) 

#exit(0)

for fnc in configfiles:
   for ln in open(fnc).readlines():
       if ln[:2] in lstofcent :
            if ln[23]=='|':
               mms=ln[:23]+' '+ln[-3:-1]
               if mms in aapc.keys():
                   pass
                   #aapc[mms]=aapc[mms]+1
                   #print mms , aapc[mms]
               else:
                   aapc[mms]=1
                   ord_ou.append(ln[:-1])

nmz='cli_'+dq+'_'+tq+'---.txt'

with open(nmz,'wt') as f_ordou:
    for ls in sorted(ord_ou):
       print >> f_ordou,ls 
    f_ordou.flush()
    f_ordou.close()

if os.stat(nmz).st_size<>0 :
   os.system("copy /Y /Z " + nmz + " " + TOPAG)
   fnmsfto.append(nmz)
else:
   os.remove(nmz)


#--===== address !!!! ----------------------------


ord_ou[:]=[]
aapc.clear()

configfiles = glob.glob("adr*ieh.txt")
#configfiles.extend(glob.glob("adr*enr.txt"))
#configfiles.extend(glob.glob("adr*lvv.txt"))

#for s in configfiles: print s
fnmsfto.extend(configfiles)

for fnc in configfiles:
   for ln in open(fnc).readlines():
       if ln[:2] in lstofcent :
            if ln[16]=='|':
               mms=ln[:-1]
               if mms in aapc.keys():
                   pass
                   #aapc[mms]=aapc[mms]+1
                   #print mms , aapc[mms]
               else:
                   aapc[mms]=1
                   ord_ou.append(ln[:-1])

nmz='adr_'+dq+'_'+tq+'---.txt'

with open(nmz,'wt') as f_ordou:
    for ls in sorted(ord_ou):
       print >> f_ordou,ls 
    f_ordou.flush()
    f_ordou.close()

if os.stat(nmz).st_size<>0 :
    os.system("copy /Y /Z " + nmz + " " + TOPAG)
    fnmsfto.append(nmz)
else : 
    os.remove(nmz)


## �����

try:
   import zlib
   compression = zipfile.ZIP_DEFLATED
except:
   compression = zipfile.ZIP_STORED

curdir_=os.getcwd()


print "########"
for s in fnmsfto: print s


zfname='all_'+dq+'_'+tq+'.zip'
#print zfname
#exit(0)

with zipfile.ZipFile(zfname, mode='a') as myzip:
    for afn in fnmsfto:
        if os.stat(afn).st_size<>0 :
            myzip.write(afn,compress_type=compression)
        os.remove(afn)
myzip.close()
os.system("copy /Y /Z " + zfname + " " + TOPAG)

dt2=datetime.now()
tt2=dt2.timetuple()
print  "------------------ ",dq,tq,"  ", ' -> {:02d}:{:02d}'.format(tt2[4],tt2[5])
