# -*- coding: utf-8 -*-

# rev 21/09/2017

# import win32com.client
import zipfile, re, os, sys, time, datetime, uuid
import glob
import string
import shutil





if __name__ == '__main__':

 cnf=dict(zip([ 14,  17,  20,  22,  28,  29,  27,   9 ,  3 ,  2 , 15,  10,
                8 ,  4 , 23,  24,  26,   7 ,  6 ,  5 ,  1 , 16,  11,  18,  21 ],
             ['05','18','32','82','71','74','68','26','73','61','07','46',
              '56','21','48','51','65','44','53','59','63','12','14','23','35']))

 shrtnm=dict(zip(['05','18','32','82','71','74','68','26','73','61','07','46',
                 '56','21','48','51','65','44','53','59','63','12','14','23','35'],
                ['vin','zht','kof','kmf','crk','crn','hmn','inf','crv','trn','vol','lvv',
                 'riv','uzh','nik','ods','hrs','lug','pol','sum','har','dnp','don','zap','kir']))

 EN_regs=('har','trn','crv','uzh','sum','pol','lug','riv','inf','lvv','don','vin','vol',
          'dnp','zht','zap','kof','kir','kmf','nik','ods','hrs','hmn','crk','crn',)

 

 TOPAG='\\\\corp\\Kyiv\\NFSResource\\EASKR\\' 
 TSUF='\\repcity\\PG_debit\\for_EASKR\\'
 TOORAG='\\\\corp\\Kyiv\\NFSResource\\EASKR\\'

 ## -----------------------
 ## U:\m\test\lfs_askr_max_lddeb.txt ����������� ���� ������� "my_max_lddeb_conn.rpt" � ������� KOF_US_DOG\DOG
 ## -----------------------

 lfs_ASKR="\\\\corp\\Kyiv\\NFSResource\\EASKR\\kof\\m\\test\\lfs_askr_max_lddeb.txt"
 
 lfs='lfs.txt'

 #F:\EASKR_BANKS\IN_OUT\US_EASKR\CONTRACTS_FROM_US\KV\
 
 sFnm_busy="__busy_ldaskr.already"

 if os.stat(lfs).st_size<>2300:
    print "SIZE of " + lfs + " is not 2300 bytes ..."
    os._exit(0)

 if os.stat(lfs_ASKR).st_size<>2300:
    print "SIZE of " + lfs_ASKR + " is not 2300 bytes ..."
    os._exit(0)


 if os.access(sFnm_busy, os.F_OK):
    print "BUSY already ..."
    sys.exit()
 else:
    pass
    #fbb=open(sFnm_busy,'wt')
    #fbb.close()


### 32_2017-09-17_200_164242.dbf

 dlf={}
 with open(lfs) as ffs:
    for r in  ffs.xreadlines():
       dlf[r[62:64]]=r.rstrip()

 dlf_ASKR={}
 with open(lfs_ASKR) as ffs:
    for r in  ffs.xreadlines():
       dlf_ASKR[r[62:64]]=r.rstrip()



 #for r in dlf.keys():
 #   print dlf[r]

 z=datetime.datetime.now()
 dt_tm= '%d%2.2d%2.2d_%2.2d%2.2d' %(z.year,z.month,z.day,z.hour,z.minute)
 #dt_ts= '%d-%2.2d-%2.2d %2.2d:%2.2d:%2.2d' %(z.year,z.month,z.day,z.hour,z.minute,z.second)
 dt_ts= '%d-%2.2d-%2.2d_200_%2.2d%2.2d%2.2d' %(z.year,z.month,z.day,z.hour,z.minute,z.second)

 print dt_ts

 #for nmf in sorted(glob.glob(TOPAG + '\\' + 'vin' + TSUF + '*.dbf')):
 #    print nmf[1]
 #print sorted(glob.glob(TOPAG + '\\' + 'kof' + TSUF + '*.dbf'),reverse=True)[1]

 #exit()

 #for rk in cnf.keys():
 #     print sorted(glob.glob(TOPAG + '\\' + shrtnm[cnf[rk]] + TSUF + cnf[rk] + '*.dbf'),reverse=True)[1]

 for rk in cnf.keys():
    if  shrtnm[cnf[rk]] in EN_regs :
        for ln in sorted(glob.glob(TOPAG + '\\' + shrtnm[cnf[rk]] + TSUF + cnf[rk] + '*.dbf'),reverse=True):
             if ln>dlf[cnf[rk]] and ln>dlf_ASKR[cnf[rk]]:
                 print ln
                 shutil.copy(ln, TOPAG + '\\' + shrtnm[cnf[rk]] + TSUF + 'input')
             else :
                 break

 with open(lfs,'wt') as ffs:
   for rk in cnf.keys():
      print >> ffs, sorted(glob.glob(TOPAG + '\\' + shrtnm[cnf[rk]] + TSUF + cnf[rk] + '*.dbf'),reverse=True)[0]



 exit()




'''

 fnmto='ord_' + dt_tm + '_pay+++.txt'
 fto=open(fnmto,"wt")
 cnf={}
 cnf[14]='05'
 cnf[17]='18'
 cnf[20]='32'
 cnf[22]='82'
 cnf[28]='71'
 cnf[29]='74'

 cnf[27]='68'
 cnf[9] ='26'
 cnf[3] ='73'
 cnf[2] ='61'
 #------------
 cnf[4] ='21'
 cnf[8] ='56'
 cnf[10]='46'
 cnf[15]='07'

 cnf[1] ='63'
 cnf[5] ='59'
 cnf[6] ='53'
 cnf[7] ='44'
 cnf[11]='14'
 cnf[16]='12'
 cnf[18]='23'
 cnf[21]='35'
 cnf[23]='48'
 cnf[24]='51'
 cnf[26]='65'

 
 shrtnm={}
 shrtnm[cnf[14]]='vin\\repcity\\PG_debit'
 shrtnm[cnf[17]]='zht\\repcity\\PG_debit'
 shrtnm[cnf[20]]='kof\\repcity\\PG_debit'
 shrtnm[cnf[22]]='kmf\\repcity\\PG_debit'
 shrtnm[cnf[28]]='crk\\repcity\\PG_debit'
 shrtnm[cnf[29]]='crn\\repcity\\PG_debit'

 shrtnm[cnf[27]]='hmn\\repcity\\PG_debit'
 shrtnm[cnf[9]] ='inf\\repcity\\PG_debit'
 shrtnm[cnf[3]] ='crv\\repcity\\PG_debit'
 shrtnm[cnf[2]] ='trn\\repcity\\PG_debit'
 #-----------------
 shrtnm[cnf[4]] ='uzh\\repcity\\PG_debit'
 shrtnm[cnf[8]] ='riv\\repcity\\PG_debit'
 shrtnm[cnf[10]]='lvv\\repcity\\PG_debit'
 shrtnm[cnf[15]]='vol\\repcity\\PG_debit'

 shrtnm[cnf[1]] ='har\\repcity\\PG_debit'
 shrtnm[cnf[5]] ='sum\\repcity\\PG_debit'
 shrtnm[cnf[6]] ='pol\\repcity\\PG_debit'
 shrtnm[cnf[7]] ='lug\\repcity\\PG_debit'
 shrtnm[cnf[11]]='don\\repcity\\PG_debit'
 shrtnm[cnf[16]]='dnp\\repcity\\PG_debit'
 shrtnm[cnf[18]]='zap\\repcity\\PG_debit'
 shrtnm[cnf[21]]='kir\\repcity\\PG_debit'
 shrtnm[cnf[23]]='nik\\repcity\\PG_debit'
 shrtnm[cnf[24]]='ods\\repcity\\PG_debit'
 shrtnm[cnf[26]]='hrs\\repcity\\PG_debit'

 
 aof=[] 

 aa={}
 aa[cnf[14]]=[]
 aa[cnf[17]]=[]
 aa[cnf[20]]=[]
 aa[cnf[22]]=[]
 aa[cnf[28]]=[]
 aa[cnf[29]]=[]

 aa[cnf[27]]=[]
 aa[cnf[9]]=[]
 aa[cnf[3]]=[]
 aa[cnf[2]]=[]

 peref={}
 peref['320001']='320100'
 peref['320002']='320101'
 peref['320003']='320200'
 peref['320004']='320202'
 peref['320005']='320203'
 peref['320006']='320300'
 peref['320007']='320304'
 peref['324700']='320400'
 peref['320009']='320405'
 peref['320010']='320406'
 peref['320011']='320500'
 peref['320012']='320507'
 peref['320013']='320508'
 peref['320014']='320600'
 peref['320015']='320609'
 peref['320016']='320700'
 peref['320017']='320710'
 peref['320018']='320800'
 peref['320019']='320811'
 peref['320020']='320900'
 peref['320021']='320912'
 peref['320022']='321000'
 peref['320023']='321013'
 peref['320024']='321100'
 peref['320025']='321114'
 peref['320008']='321115'
 peref['050000']='054000'
 peref['050001']='050206'
 peref['050002']='050718'
 peref['050003']='050100'
 peref['050004']='050200'
 peref['050005']='050103'
 peref['050006']='050411'
 peref['050007']='050400'
 peref['050008']='050617'
 peref['050009']='050720'
 peref['050010']='050104'
 peref['050011']='050309'
 peref['050012']='050500'
 peref['050013']='050512'
 peref['050014']='050101'
 peref['050015']='050105'
 peref['050016']='050616'
 peref['050017']='050410'
 peref['050018']='050102'
 peref['050019']='050208'
 peref['050020']='050600'
 peref['050021']='050700'
 peref['050022']='050614'
 peref['050023']='050300'
 peref['050024']='050513'
 peref['050025']='050719'
 peref['050026']='050207'
 peref['050027']='050615'
 peref['734000']='733300'
 peref['460005']='460200'

 ##--------------------------
 for key in cnf.keys():
       ## ������� �������� ������ - 2, 3, 9, 27, 4, 8, 10, 15,

       #if key in (1,  5, 6, 7, 11, 16, 18, 21, 23, 24, 26):
       #     continue

       TOPA=TOORAG+shrtnm[cnf[key]]
 
       for nmf in glob.glob(TOPA+'\\'+'*.txt'):
           #print nmf
           mtmf=time.localtime(os.path.getmtime(nmf))
           mtmz=datetime.datetime(mtmf.tm_year, mtmf.tm_mon, mtmf.tm_mday, mtmf.tm_hour, mtmf.tm_min, mtmf.tm_sec)
           c=(z-mtmz).seconds/60
           #print c.seconds/60, mtmz, z

           ## �������� ����� 10 �������� �������� ����� (���� �������� ������ ������������ �������� ����� �����)
           if c>=10 : 
               aof.append(nmf)
               for ln in open(nmf).readlines():
                      mss=ln[:-1].rstrip().split("|")
                      if mss[0] in peref.keys():
                             mss[0]=peref[mss[0]]
                      mss[6]=dt_ts
                      mss[7]=mss[7] +" "+  os.path.basename(nmf)
                      print >> fto, "|".join(mss)



       #   print nmf[0:-5]+nmf[-4:]
       #   if os.access(nmf, os.F_OK):
       #        os.remove(nmf) if(os.stat(nmf).st_size==0) else os.rename(nmf, TOPA + nmf[0:-5]+nmf[-4:])
       
       #if os.access(nmto, os.F_OK):
       #      os.rename(nmto, nmto + '.' + dt_tm)
       #os.rename(nmf,nmto)

 print "----\n",dt_tm,dt_ts
 fto.close()

 #print aof

 if os.access(fnmto, os.F_OK):
        os.rename(fnmto, TOORAG+"\\kof\\repcity\\PG_debit\\MMM\\"+fnmto)

 for nmf in  aof:
      print os.path.dirname(nmf)
      print os.path.basename(nmf)
      if os.access(nmf, os.F_OK):
             os.rename(nmf,os.path.dirname(nmf)+"\\Done\\" + os.path.basename(nmf))

 if  os.access(sFnm_busy, os.F_OK):
     os.remove(sFnm_busy)
 
'''
 