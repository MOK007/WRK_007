# -*- coding: utf-8 -*-

## ------- ver. 18.07.2017 ������� ���
## ------- ver. 10.07.2017 ������� pattern ��� 4 ����� ����
## ------- ver. 03.05.2017 ������� pattern ��� 17 �����
## ------- ver. 31.01.2017 ������� pattern ��� 10 �����
## ------- ver. 22.04.2016


import win32com.client
import time
#from datetime import datetime, timedelta
import datetime
import os,shutil
import re
from subprocess import Popen, PIPE, STDOUT
import glob

global pppzxc

## ���� �������� !!!

TOPA='\\\\kv-kr-kof-s013\\kv-kr-kof-easkr\\docs\\EASKR_BANKS\\IN_OUT\\US_EASKR\\'
#TOPA='\\\\kv-kr-kof-s013\\kv-kr-kof-easkr\\docs\\EASKR_BANKS\\IN_OUT\\'
TOORAG='\\\\corp\\Kyiv\\NFSResource\\EASKR\\'

pppzxc={} 
cnf={}
cnf[14]='05'
cnf[17]='18'
cnf[20]='32'
cnf[22]='82'
cnf[28]='71'
cnf[29]='74'

cnf[27]='68'
cnf[9] ='26'
cnf[3] ='73'
cnf[2] ='61'

cnf[15]='07'
cnf[10]='46'
cnf[8] ='56'
cnf[4] ='21'

cnf[23]='48'
cnf[24]='51'
cnf[26]='65'

cnf[7] ='44'
cnf[6] ='53'
cnf[5] ='59'
cnf[1] ='63'

cnf[16]='12'
cnf[11]='14'
cnf[18]='23'
cnf[21]='35'




shrtnm={}

shrtnm[cnf[14]]='vin'
shrtnm[cnf[17]]='zht'
shrtnm[cnf[20]]='kof'
shrtnm[cnf[22]]='kmf'
shrtnm[cnf[28]]='crk'
shrtnm[cnf[29]]='crn'

shrtnm[cnf[27]]='hmn'
shrtnm[cnf[9]] ='inf'
shrtnm[cnf[3]] ='crv'
shrtnm[cnf[2]] ='trn'

shrtnm[cnf[15]]='vol'
shrtnm[cnf[10]]='lvv'
shrtnm[cnf[8]] ='riv'
shrtnm[cnf[4]] ='uzh'

shrtnm[cnf[23]]='nik'
shrtnm[cnf[24]]='ods'
shrtnm[cnf[26]]='hrs'

shrtnm[cnf[7]] ='lug'
shrtnm[cnf[6]] ='pol'
shrtnm[cnf[5]] ='sum'
shrtnm[cnf[1]] ='har'

shrtnm[cnf[16]]='dnp'
shrtnm[cnf[11]]='don'
shrtnm[cnf[18]]='zap'
shrtnm[cnf[21]]='kir'


aa={}
aa[cnf[14]]=[]
aa[cnf[17]]=[]
aa[cnf[20]]=[]
aa[cnf[22]]=[]
aa[cnf[28]]=[]
aa[cnf[29]]=[]

aa[cnf[27]]=[]
aa[cnf[9]]= []
aa[cnf[3]]= []
aa[cnf[2]]= []

aa[cnf[15]]=[]
aa[cnf[10]]=[]
aa[cnf[8]]= []
aa[cnf[4]]= []

aa[cnf[23]]=[]
aa[cnf[24]]=[]
aa[cnf[26]]=[]

aa[cnf[7]] =[]
aa[cnf[6]] =[]
aa[cnf[5]] =[]
aa[cnf[1]] =[]

aa[cnf[16]]=[]
aa[cnf[11]]=[]
aa[cnf[18]]=[]
aa[cnf[21]]=[]



#if os.access('aaa.txt', os.F_OK):
#   stats=os.stat('aaa.txt')
#   print stats
#   os.remove('aaa.txt') if(os.stat('aaa.txt').st_size==0) else os.rename('aaa.txt','aaa.tx$')
#exit()

outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")

inbox = outlook.GetDefaultFolder(6).Parent.Folders["_���������"]

### print "Inbox name is:", inbox.Name.encode('cp1251')

fnall="_mmm_in.txt"
out_F=open(fnall,"wt")

sbottom="20150402 000000"
# exit(0)
if os.path.exists("__mes_corectCMR.txt"):
   zfdt=open("__mes_corectCMR.txt","r+")
   sbottom=zfdt.read().rstrip()
else:
   zfdt=open("__mes_corectCMR.txt","w")
   pass

# print sbottom
sbottommax=sbottom

#EXCEL_DATE_SYSTEM_PC=1900
#i = 42129  # Excel number for 5-May-2015
#d = datetime.date(EXCEL_DATE_SYSTEM_PC, 1, 1) + datetime.timedelta(i-2)

messages = inbox.Items
message = messages.GetFirst ()
pttrn = re.compile('((82|32|74|71|05|18|68|26|73|61|07|46|56|21|48|51|65|44|53|59|63|12|14|23|35)[0-9]{14,14})',re.IGNORECASE)
pttrn2=re.compile('^(82|32|74|71|05|18|68|26|73|61|07|46|56|21|48|51|65|44|53|59|63|12|14|23|35)',re.IGNORECASE)

z=datetime.datetime.now()

while message:
    # if message.Subject.startswith('Oschadbank'):
    a=message.ReceivedTime
    sbottomr='%d%2.2d%2.2d %2.2d%2.2d%2.2d' %(a.year,a.month,a.day,a.hour,a.minute,a.second)
    if(sbottomr > sbottommax):
        if(sbottom < sbottomr) : sbottom=sbottomr

        #print time.strptime(message.ReceivedTime,"%Y%m%d%H%M%S")
        #print datetime.now().strftime("%d.%m.%Y %I:%M %p"),
        #print type(message.ReceivedTime)
        #print message.ReceivedTime.strftime("%d.%m.%Y %I:%M %p")
        #print message.ReceivedTime.strftime("%d.%m.%y")
        a=message.ReceivedTime
        # print d.strftime("%d.%m.%Y %I:%M %p")
        z=datetime.datetime.now()
        #print z, z.strftime("%d.%m.%Y %I:%M %p"), 
        # print '%d%2.2d%2.2d %2.2d%2.2d%2.2d-%d' %(z.year,z.month,z.day,z.hour,z.minute,z.second,z.microsecond),
        # print '%d%2.2d%2.2d %2.2d%2.2d%2.2d' %(a.year,a.month,a.day,a.hour,a.minute,a.second),
        # print filename
        # sbottomr='%d%2.2d%2.2d %2.2d%2.2d%2.2d' %(a.year,a.month,a.day,a.hour,a.minute,a.second)
        #a.year,a.day,a.month,datetime.date.fromtimestamp(a)
        #a.hour,a.minute,d.day,a.month,a.year

        ## --------------------------------------
        ## -- ATTACHMENTS
        ## --------------------------------------
        attachments = message.Attachments
        if attachments.Count>=1 :
             try:
                  for pp in range(attachments.Count):
                     attachment = attachments.Item(pp+1)
                     filename = 'D:\\tmp\\XX\\%s'%attachment.FileName
                     # filename ='\\\\kv-kr-kof-s013\\kv-kr-kof-easkr\\docs\\EASKR_BANKS\\banks\\-----PORTMONE-----\\IN\\%s'%attachment.FileName
                     mrk=attachment.FileName[0:3].lower()
                     if ( filename[-3:].lower()=='txt' 
                          and sbottomr >= sbottom 
                          ## and mrk in ('cli','ord')
                        ):
                             # print sbottomr,sbottom ,sbottommax
                             # print sbottomr, filename
                             attachment.SaveAsFile(filename)
                             fp=open(filename)
                             lns =fp.readlines()
                             for ln in lns:
                                  sd=re.findall(pttrn,ln)
                                  if  sd :
                                      for psd in sd:
                                         pass
                                         aa[psd[1]].append(psd[0])
                                         ## print psd[0]
                                         pppzxc[psd[0]]="|"
         
                             fp.close()
                             # os.remove(filename)
             except:
                  pass
        ## --------------------------------------
        ## BODY
        ## --------------------------------------
        fp=open('mmm.txt','w')
        fp.write(message.Body.encode('cp1251','replace'))
        fp.close()
        fp=open('mmm.txt')
        lns =fp.readlines()
        for ln in lns:
              sd=re.findall(pttrn,ln)
              if  sd :
                  for psd in sd:
                      pass
                      aa[psd[1]].append(psd[0])
                      # print psd[0],psd[1],aa
                      pppzxc[psd[0]]="|"

        fp.close()

        ## --------------------------------------
        ## Subject
        ## --------------------------------------
        sd=re.findall(pttrn,message.Subject)
        if  sd :
            for psd in sd:
                pass
                aa[psd[1]].append(psd[0])
                ## print psd[0]
                pppzxc[psd[0]]="|"
                       
    message = messages.GetNext()

### print "-----------"

kk=0
g0=""
for key in sorted(pppzxc.keys()):
     print key+pppzxc[key]
     
     #print >> out_F, key+","
     g0=g0+key+","
     if kk in(9,19,29,39):
         print >> out_F, g0
         g0=""
     
     kk=kk+1
     if(kk==40) : break
if len(g0)>0 : print >> out_F, g0

print >> out_F,"0,\n0,\n0,\n0,\n0,"


print "^^^^^^^^"

out_F.close()
#shutil.copy(fnall,TOORAG+"kof\\repcity")
#shutil.copy(fnall,TOORAG+"zht\\repcity")
#shutil.copy(fnall,TOORAG+"inf\\repcity")
shutil.copy(fnall,TOORAG + "kof\\m\\2\\in_pc_test.txt")

#exit()


##### �������� !!!!!! 
##### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
#######zfdt.seek(0)
#######zfdt.write(sbottom)
#######zfdt.close()
#######out_F.close()
#######exit()
##### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
##### !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

# z=datetime.datetime.now()
# print '%d%2.2d%2.2d %2.2d%2.2d' %(z.year,z.month,z.day,z.hour,z.minute)

dt_tm= '%d%2.2d%2.2d %2.2d%2.2d' %(z.year,z.month,z.day,z.hour,z.minute)
#for keycnf in cnf.keys():
#         if (aa[cnf[keycnf]]):
#            g0= ','.join(aa[cnf[keycnf]][ 0:10]) if(aa[cnf[keycnf]][ 0: 1]) else '0'
#            g1= ','.join(aa[cnf[keycnf]][10:20]) if(aa[cnf[keycnf]][10:11]) else '0'
#            g2= ','.join(aa[cnf[keycnf]][20:30]) if(aa[cnf[keycnf]][20:21]) else '0'
#            g3= ','.join(aa[cnf[keycnf]][30:40]) if(aa[cnf[keycnf]][30:31]) else '0'
#         else :
#            g0='0'
#            g1='0'
#            g2='0'
#            g3='0'
#         # print dt_tm,keycnf,shrtnm[keycnf],g0,g1,g2,g3
#         clstr=('ascren' if (keycnf==17) else 'ascrin')
#         #print clstr
#         cmd="sqlplus  -L -S omeshkov/12341234@%s @mm_CMR_by_post.sql %s %s %s %s %s %s %s" % (clstr,dt_tm,keycnf,shrtnm[keycnf],g0,g1,g2,g3)
#         # print cmd
#
#         if (keycnf<>21) :
#              print keycnf,shrtnm[keycnf] 
#              p = Popen(cmd , shell=True, stdout=PIPE, stderr=PIPE)
#              out, err = p.communicate()
#              print "Yes_Yes_Yes: ", p.returncode
#              print out.rstrip(), err.rstrip()
#              # cleanup
#              p.stdout.close()
#              if p.stderr:
#                  p.stderr.close()
#              # p.stdin.close()
#              p.wait()

#if os.access('aaa.txt', os.F_OK):
#   stats=os.stat('aaa.txt')
#   print stats
#   os.remove('aaa.txt') if(os.stat('aaa.txt').st_size==0) else os.rename('aaa.txt','aaa.tx$')
#exit()

#for nmf in glob.glob('*_.txt'):
#   print nmf
#   print nmf[0:-5]+nmf[-4:]
#   if os.access(nmf, os.F_OK):
#        os.remove(nmf) if(os.stat(nmf).st_size==0) else os.rename(nmf, TOPA + nmf[0:-5]+nmf[-4:])



#mrk=''
#mrksnd_mail=''
#for nmf in glob.glob('*_.txt'):
#    mrksnd_mail='s'
#    print nmf
#    with open(nmf) as f:
#      mrk=''
#      for line in f:
#         if re.findall(pttrn2,line):
#             if not mrk :
#                 fto=open(TOPA + nmf[0:-5]+nmf[-4:],'wt')
#                 mrk='+'
#             # print line[0:-1]
#             fto.write(line)
#      if(mrk) : fto.close()
#    f.close()
#    os.remove(nmf)

print "^---^^^^^^^"

#print cmd
#cmd = "sqlplus  -L -S omeshkov/12341234@ascrin @mm_CMR_by_post.sql 20160404 1018 14 vn 0500009100038051,0500009100037931,0500009100136201,0500009100203521,0500009100135921,0500009100040761,0500009100460591,0500009100993431 0 0 0"
#p = Popen(cmd , shell=True, stdout=PIPE, stderr=PIPE)
#out, err = p.communicate()
#print "Return code: ", p.returncode
#print out.rstrip(), err.rstrip()



zfdt.seek(0)
zfdt.write(sbottom)
zfdt.close()

##########################

exit()
mrksnd_mail='s'

if mrksnd_mail :
   olMailItem = 0x0
   obj = win32com.client.Dispatch("Outlook.Application")
   newMail = obj.CreateItem(olMailItem)
   newMail.Subject = "$$ ������ ����������"
   newMail.Body = """
   ������ ����.

   �������� ������ ����������.

   ���.: 
   +380 (44) 258-59-13

   """


   #newMail.To = "nsmoliar@ukrtelecom.ua"
   newMail.To = "omeshkov@ukrtelecom.ua"
   #newMail.CC = "omeshkov@ukrtelecom.ua; tlytvyn@ukrtelecom.ua"

   #newMail.BCC = "address"
   #attachment1 = "D:\\_ARBEITEN\\Reestr\\BANKS\\KOF_banks_Post.xls"
   #attachment2 = "Path to attachment no. 2"
   #newMail.Attachments.Add(attachment1)
   #newMail.Attachments.Add(attachment2)
   #newMail.display()
   newMail.Send()
